package com.example.myfragmentapp.ui.activity;


import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;


import android.os.Bundle;

import com.example.myfragmentapp.ui.fragment.BlankFragment;
import com.example.myfragmentapp.ui.fragment.FragmentStart;
import com.example.myfragmentapp.R;

public class MainActivity extends AppCompatActivity implements FragmentStart.StfrtFragment2 {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState==null){
            getSupportFragmentManager().beginTransaction().
                    add(R.id.fl_container, FragmentStart.newInstans(), "Panel1")
                    .commit();
        }

    }

    @Override
    public void stertFrag(String s) {
        getSupportFragmentManager().beginTransaction().setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                .replace(R.id.fl_container, BlankFragment.newInstance(s,"vvv"),"Panel2").addToBackStack("cansel")
                .commit();
    }



}
