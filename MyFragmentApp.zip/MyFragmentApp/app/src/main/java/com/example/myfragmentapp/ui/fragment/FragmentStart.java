package com.example.myfragmentapp.ui.fragment;


import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.myfragmentapp.R;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentStart extends Fragment {
    private EditText editText;
    private Button button;
    private ImageView imageView;

    public interface StfrtFragment2 {
         void stertFrag(String s);
    }

    StfrtFragment2 stfrtFragment2;


    public static FragmentStart newInstans() {
        FragmentStart fragmentStart = new FragmentStart();
        return fragmentStart;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       try {
           stfrtFragment2=(StfrtFragment2) context;
       }catch (RuntimeException e){

       }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_start_layout, null, false);
        editText = view.findViewById(R.id.et_frg1);
        imageView=view.findViewById(R.id.imageView);
        button = view.findViewById(R.id.bt_frg1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stfrtFragment2 == null) {
                    Toast.makeText(getContext(), "eror", Toast.LENGTH_LONG).show();
                }
                String text = editText.getText().toString();
                stfrtFragment2.stertFrag(text);

            }
        });
        return view;
    }



}
